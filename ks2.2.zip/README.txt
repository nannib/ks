How to use KS

KS.sh is a Bash script for finding text and strings.

It extracts all deleted files; slackspace; It makes a data carving on the freespace only; It indexes all by RECOLL. 
You need:
The Sleuthkit (last release)
Photorec
MD5Deep
RECOLL
It stores the index DB and the recoll.conf in the chosen output directory. 

First of all after to have installed RECOLL, put the files:

mimeconf 
mimemap

into 

/root/.recoll
/home/username/.recoll
~/.recoll/

If does not work copy the content of usr_share_recoll_examples into /usr/share/recoll/examples

and then put rclbin into

/usr/share/recoll/filters
and make it executable
sudo chmod +x /usr/share/recoll/filters/rclbin

If you need to add others file types you can add them changing mimeconf and mimemap files.

it runs using:
sudo bash ks.sh

Thanks


Nanni Bassetti
http://www.nannibassetti.com - digitfor@gmail.com
http://www.caine-live.net
