#!/bin/bash 
#
# KS - by Nanni Bassetti - digitfor@gmail.com - http://www.nannibassetti.com 
# release: 2.2
#
# It mounts a DD image file or a block device, it extracts all deleted files,
# it makes a data carving on the unallocated space, the it runs recoll 
# changing automatically the variables in recoll.conf.
#
# many thanks to Raul Capriotti, Jean-Francois Dockes, Cristophe Grenier,
# Raffaele Colaianni, Gianni Amato, John Lehr,Alessandro Farina


echo -e "KS 2.2 - by Nanni Bassetti - digitfor@gmail.com - http://www.nannibassetti.com \n"
while :
do
   echo -e "\nInsert the image file or the device (absolute path): "
   read imm
   [[ -f $imm || -b $imm ]] && break
done
while :
do
   echo "Insert the output directory (absolute path):"
   read outputdir
   [[ "${outputdir:0:1}" = / ]] && { 
      [[ ! -d $outputdir ]] && mkdir $outputdir
      break
   }
done

(! mmls $imm 2>/dev/null 1>&2) && {
   echo "0"
   echo "The starting sector is '0'"
   so=0
} || {
   mmls $imm
   echo -e "\nChoose the starting sector of the partition you need to index"
   read so
}

HASHES_FILE=$outpudir/hashes.txt      # File output hash
DIR_DELETED=$outputdir/deleted        # Deleted File's Folder
DIR_SLACK=$outputdir/slackspace       # Slackspace's Folder
DIR_FREESPACE=$outputdir/freespace    # Carved File's Folder
BASE_IMG=$(basename $imm)             # Basename of the image or device

[[ ! -d $outputdir/$BASE_IMG ]] && mkdir $outputdir/$BASE_IMG

off=$(( $so * 512 ))
mount -t auto -o ro,loop,offset=$off,umask=222 $imm $outputdir/$BASE_IMG >/dev/null 2>&1 && {
echo "Image file mounted in '$outputdir/$BASE_IMG'"
}

# recovering the deleted files
echo "recovering the deleted files..."
[[ ! -d $DIR_DELETED ]] && mkdir $DIR_DELETED
tsk_recover -o $so $imm $DIR_DELETED

# extracting slack space
echo "extracting slack space..."
[[ ! -d $DIR_SLACK ]] && mkdir $DIR_SLACK
blkls -s -o $so $imm > $DIR_SLACK/slackspace.txt 

# freespace and carving

[[ ! -d $DIR_FREESPACE ]] && mkdir $DIR_FREESPACE || {
rm -R $DIR_FREESPACE
mkdir $DIR_FREESPACE
}

# using photorec to carve inside the freespace

photorec /d $DIR_FREESPACE/ /cmd $imm fileopt,everything,enable,freespace,search

# taking off duplicates from carving directory
echo "taking off duplicates from carving directory..."
[[ $(ls $DIR_DELETED) ]]  && md5deep -r $DIR_DELETED/* > $HASHES_FILE
[[ $(ls $DIR_FREESPACE) ]] && md5deep -r $DIR_FREESPACE/* >> $HASHES_FILE
awk 'x[$1]++ { FS = " " ; print $2 }' $HASHES_FILE | xargs rm -rf
[[ -f $HASHES_FILE ]] && rm $HASHES_FILE

# RECOLL configuration to have a single recoll.conf and xapiandb for each case examined.
echo "RECOLL is indexing..."
rcldir=$outputdir/recoll
recollconf=/$rcldir/recoll.conf
mkdir -p $rcldir/xapiandb

cat > $recollconf << EOF
topdirs = $outputdir
dbdir = $rcldir/xapiandb
processbeaglequeue = 1
skippedPaths = $rcldir $rcldir/xapiandb
indexallfilenames = 1
textfilemaxmbs = -1 # for indexing txt files greater than 10Mb thanks to Alessandro Farina
usesystemfilecommand = 1
indexstemminglanguages = italian english spanish
EOF

recollindex -c $rcldir -z >/dev/null 2>&1
case $(tty) in
   /dev/tty*) echo -e "\nStart on terminal from graphic interface the following command:"
              echo -e "recoll -c $rcldir\n"
              exit 1
              ;;
           *) recoll -c $rcldir >/dev/null 2>&1 &
              exit 0
              ;;
esac
